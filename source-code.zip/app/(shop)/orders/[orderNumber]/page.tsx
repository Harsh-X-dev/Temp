"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { createSupabaseBrowserClient } from "@/services/supabase/client";
import { fetchCustomerOrders } from "@/services/orders.service";
import type { OrderDetail } from "@/components/account/types";

import Link from "next/link";
import OrderDetailPageHeader from "@/components/orders/headers/OrderDetailPageHeader";
import OrderSummaryCard from "@/components/orders/cards/OrderSummaryCard";
import OrderTrackingTimeline from "@/components/orders/timeline/OrderTrackingTimeline";
import DeliveryAddressCard from "@/components/orders/cards/DeliveryAddressCard";
import PaymentSummaryCard from "@/components/orders/cards/PaymentSummaryCard";
import CancelOrderButton from "@/components/orders/CancelOrderButton";
import { OrderHistorySkeleton } from "@/components/orders/states/OrderStates";

export default function OrderTrackingPage() {
  const { orderNumber } = useParams<{ orderNumber: string }>();
  const { isAuthenticated, loading, initialized } = useAuth();
  const router = useRouter();

  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialized && !loading && !isAuthenticated) {
      router.replace(`/login?redirectTo=/orders/${orderNumber}`);
    }
  }, [initialized, loading, isAuthenticated, router, orderNumber]);

  useEffect(() => {
    async function loadOrder() {
      if (!isAuthenticated) return;
      try {
        const supabase = createSupabaseBrowserClient();
        const data = await fetchCustomerOrders(supabase);
        
        // Find real order
        const realOrder = data.find((o) => o.orderNumber === orderNumber);
        
        if (realOrder) {
          setOrder(realOrder);
        } else {
          setError("Order not found");
        }
      } catch (err: any) {
        setError(err.message || "Failed to load order details");
      } finally {
        setIsLoading(false);
      }
    }
    loadOrder();
  }, [isAuthenticated, orderNumber]);

  if (!initialized || loading || (isAuthenticated && isLoading)) {
    return (
      <div className="bg-[#FDFBF7] md:bg-white min-h-[100dvh] flex flex-col">
        <OrderDetailPageHeader />
        <div className="flex-1 lg:py-8 max-w-7xl mx-auto w-full pt-6 px-[16px] md:px-8">
          <OrderHistorySkeleton />
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="bg-[#FDFBF7] md:bg-white min-h-[100dvh] flex flex-col">
        <OrderDetailPageHeader />
        <div className="flex-1 flex items-center justify-center py-16">
          <div className="text-center">
            <h2 className="text-lg font-bold text-text-primary">Order Not Found</h2>
            <p className="mt-2 text-sm text-text-secondary">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#F8F6F0] flex-1 flex flex-col font-['Montserrat']">
      <OrderDetailPageHeader />
      <div className="flex-1 lg:py-8 max-w-lg mx-auto w-full pt-4 lg:pt-0 pb-12 px-[16px] md:px-8 space-y-4">
        <OrderSummaryCard order={order} />
        <OrderTrackingTimeline events={order.trackingEvents} />
        <DeliveryAddressCard address={order.deliveryAddress} />
        <PaymentSummaryCard payment={order.paymentSummary} />
        <CancelOrderButton orderNumber={order.orderNumber} status={order.status} />

        {/* Need Help & Refund Policy Links */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-6">
          {/* <Link
            href="/support"
            className="flex items-center gap-2 text-sm text-[#6B6459] font-medium hover:text-primary-orange transition-colors"
          >
            <svg
              className="size-4 text-[#8C8477]"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            <span className="underline decoration-[#8C8477] underline-offset-2">
              Need Help?
            </span>
          </Link> */}

          <Link
            href="/refund-policy"
            className="flex items-center gap-2 text-sm text-[#6B6459] font-medium hover:text-primary-orange transition-colors"
          >
            <svg
              className="size-4 text-[#8C8477]"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <span className="underline decoration-[#8C8477] underline-offset-2">
              Refund Policy
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}
