"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useAuthStore } from "@/store/auth.store";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "@/services/supabase/client";
import { fetchCustomerOrders } from "@/services/orders.service";
import type { Order } from "@/components/account/types";

import OrdersPageHeader from "@/components/orders/headers/OrdersPageHeader";
import OrderStatusFilter from "@/components/orders/states/OrderStatusFilter";
import OrderHistoryCard from "@/components/orders/cards/OrderHistoryCard";
import { OrderHistoryPageSkeleton, OrdersEmptyState } from "@/components/orders/states/OrderStates";

const STATUSES = ["All", "Processing", "Shipped", "Delivered", "Cancelled"];

export default function OrdersPage() {
  const { isAuthenticated, loading, initialized } = useAuth();
  // Read user directly from the store — it is set as soon as the session is
  // confirmed, before profile/addresses finish loading, so we can start the
  // data fetch without waiting for the full auth initialization sequence.
  const user = useAuthStore((s) => s.user);
  const router = useRouter();

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState("All");

  useEffect(() => {
    if (initialized && !loading && !isAuthenticated) {
      router.replace("/login?redirectTo=/orders");
    }
  }, [initialized, loading, isAuthenticated, router]);

  // Fire the data fetch as soon as we have a confirmed user (doesn't wait for
  // the full auth init waterfall — saves one sequential round-trip).
  useEffect(() => {
    if (!user) {
      // No user yet — clear loading so unauthenticated users aren't stuck on
      // skeleton while waiting for the redirect to /login.
      setIsLoadingOrders(false);
      return;
    }
    setIsLoadingOrders(true);
    async function loadOrders() {
      try {
        const supabase = createSupabaseBrowserClient();
        const data = await fetchCustomerOrders(supabase);
        setOrders(data);
      } catch (err: any) {
        setError(err.message || "Failed to load orders");
      } finally {
        setIsLoadingOrders(false);
      }
    }
    loadOrders();
  }, [user?.id]);

  const filteredOrders = orders.filter((order) => {
    if (selectedStatus === "All") return true;

    const dbStatus = order.status.toLowerCase();
    const uiStatus = selectedStatus.toLowerCase();

    if (uiStatus === "processing") {
      return ["pending", "confirmed", "processing"].includes(dbStatus);
    }
    if (uiStatus === "cancelled") {
      return ["cancelled", "returned", "refunded"].includes(dbStatus);
    }

    return dbStatus === uiStatus;
  });

  // Show skeleton while auth is initializing OR while the orders fetch is in
  // flight — prevents the empty-state flash before data arrives.
  if (!initialized || loading || isLoadingOrders) {
    return <OrderHistoryPageSkeleton />;
  }

  return (
    <div className="bg-[#fbf8f4] flex-1 h-full flex flex-col">
      <OrdersPageHeader />
      <div className="flex flex-col gap-4 px-6 pt-4 pb-20 md:pb-6 w-full">
        <OrderStatusFilter
          statuses={STATUSES}
          selectedStatus={selectedStatus}
          onSelect={setSelectedStatus}
        />

        {error ? (
          <div className="rounded-lg bg-red-50 p-4 text-center text-red-600 border border-red-100">
            {error}
          </div>
        ) : filteredOrders.length > 0 ? (
          <div className="flex flex-col gap-3 w-full">
            {filteredOrders.map((order) => (
              <OrderHistoryCard key={order.id} order={order} />
            ))}
          </div>
        ) : (
          <OrdersEmptyState />
        )}
      </div>
    </div>
  );
}
