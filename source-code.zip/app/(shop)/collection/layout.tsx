import Container from "@/components/layout/Container";
import { getActiveCollections } from "@/services/collection.service";

/**
 * Collection layout — Server Component.
 *
 * Wraps every /collection/* page. Fetches active collections from Supabase
 * and passes them to CategoryBar (Client Component). CategoryBar stays
 * mounted as the user navigates between categories, preserving scroll position.
 */
export default async function CollectionLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const categories = await getActiveCollections();

  return (
    <>
      <Container className="pt-4 md:pt-6 lg:pt-8 pb-20 md:pb-6 lg:pb-8">
        {children}
      </Container>
    </>
  );
}
