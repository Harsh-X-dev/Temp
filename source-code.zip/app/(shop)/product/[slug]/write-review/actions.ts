'use server';

import { createSupabaseServerAuthClient } from "@/services/supabase/server";
import { submitReview } from "@/services/reviews.service";

export async function submitReviewAction(formData: FormData) {
  const supabase = await createSupabaseServerAuthClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return { success: false, error: "Must be logged in to submit a review." };
  }

  // Ensure user_id is attached
  if (!formData.get("user_id")) {
    formData.set("user_id", user.id);
  }

  // Ensure user_name is attached if missing
  let userName = formData.get("user_name") as string;
  if (!userName || /^\+?[0-9]{7,15}$/.test(userName.trim())) {
    userName = user.user_metadata?.full_name || user.user_metadata?.name;
    
    if (!userName) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("id", user.id)
        .maybeSingle();
      userName = profile?.full_name;
    }

    formData.set("user_name", userName || "Verified Customer");
  }

  // Ensure order_id is attached if missing
  let orderId = formData.get("order_id") as string;
  if (!orderId) {
    const { data: recentOrder } = await supabase
      .from("orders")
      .select("id")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    orderId = recentOrder?.id || "00000000-0000-0000-0000-000000000000";
    formData.set("order_id", orderId);
  }

  try {
    const res = await submitReview(formData);
    return { success: true, data: res };
  } catch (error: any) {
    console.error('[submitReviewAction] Error submitting review:', error);
    return { success: false, error: error.message || "Failed to submit review." };
  }
}
