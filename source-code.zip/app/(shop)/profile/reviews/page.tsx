"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useAuthStore } from "@/store/auth.store";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "@/services/supabase/client";
import { fetchCustomerReviews, fetchPendingReviews } from "@/services/reviews.service";
import type { Review } from "@/components/account/types";

import ReviewsPageHeader from "@/components/reviews/ReviewsPageHeader";
import ReviewSummaryCard from "@/components/reviews/ReviewSummaryCard";
import PendingReviewsCallout from "@/components/reviews/PendingReviewsCallout";
import ReviewHistoryCard from "@/components/reviews/ReviewHistoryCard";
import { ReviewsSkeleton, ReviewsEmptyState } from "@/components/reviews/ReviewsStates";

export default function ReviewsPage() {
  const { profile, isAuthenticated, loading, initialized } = useAuth();
  // Read user directly from the store — set as soon as the session is confirmed,
  // so we can start the data fetch in parallel with auth init.
  const user = useAuthStore((s) => s.user);
  const router = useRouter();

  const [reviews, setReviews] = useState<Review[]>([]);
  const [pendingCount, setPendingCount] = useState<number>(0);
  const [isLoadingReviews, setIsLoadingReviews] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialized && !loading && !isAuthenticated) {
      router.replace("/login?redirectTo=/profile/reviews");
    }
  }, [initialized, loading, isAuthenticated, router]);


  // Fire the data fetch as soon as we have a confirmed user (doesn't wait for
  // the full auth init waterfall — saves one sequential round-trip).
  useEffect(() => {
    if (!user) return;
    async function loadReviews() {
      try {
        const supabase = createSupabaseBrowserClient();
        const [data, pendingData] = await Promise.all([
          fetchCustomerReviews(supabase),
          fetchPendingReviews(supabase)
        ]);
        
        setReviews(data);
        setPendingCount(pendingData.length);
      } catch (err: any) {
        setError(err.message || "Failed to load reviews");
      } finally {
        setIsLoadingReviews(false);
      }
    }
    loadReviews();
  }, [user?.id]);

  const totalReviews = reviews.length;
  const averageRating = totalReviews > 0
    ? reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviews
    : 0;

  // Real pending count is now fetched from Supabase

  // Only block on auth initializing — not on the data fetch itself.
  if (!initialized || loading) {
    return (
      <div className="bg-surface-subtle min-h-[100dvh] flex flex-col">
        <ReviewsPageHeader />
        <div className="flex-1 lg:py-8 max-w-7xl mx-auto w-full px-[16px] md:px-8">
          <ReviewsSkeleton />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-surface-subtle min-h-[100dvh] flex flex-col">
      <ReviewsPageHeader />
      {/* Scroll Content: exact Figma spacing */}
      <div className="flex-1 max-w-7xl mx-auto w-full flex flex-col gap-[16px] pt-[16px] pb-[32px] px-[24px]">

        <ReviewSummaryCard
          profile={profile}
          totalReviews={totalReviews}
          averageRating={averageRating}
        />

        {/* List Heading */}
        <div className="flex items-center justify-between w-full whitespace-nowrap">
          <p className="text-[13px] font-bold text-text-primary leading-normal">
            Your Past Reviews ({totalReviews})
          </p>
          <p className="text-[12px] font-medium text-text-muted leading-normal">
            Most Recent First
          </p>
        </div>

        {/* Reviews Stack */}
        {error ? (
          <div className="rounded-[12px] bg-red-50 p-[16px] text-center text-red-600 border border-red-100">
            {error}
          </div>
        ) : reviews.length > 0 ? (
          <div className="flex flex-col gap-[12px] w-full">
            {reviews.map((review) => (
              <ReviewHistoryCard key={review.id} review={review} />
            ))}
          </div>
        ) : (
          <ReviewsEmptyState />
        )}

        <PendingReviewsCallout count={pendingCount} />
      </div>
    </div>
  );
}
