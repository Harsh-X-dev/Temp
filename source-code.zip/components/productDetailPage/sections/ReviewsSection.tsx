'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Review } from '@/types/product.types';
import { IconStarFilled, IconStarOutline, IconCheck, IconThumbsUp, IconThumbsUpFilled } from '@/components/productDetailPage/Icons';
import { toast } from '@/lib/toast';
import { markReviewHelpful } from '@/services/reviews.service';

interface ReviewsSectionProps {
  rating: number;
  reviewCount: number;
  reviews: Review[];
  productSlug: string;
  reviewEligibility?: { 
    eligible: boolean; 
    reason: 'ELIGIBLE' | 'NOT_LOGGED_IN' | 'NOT_PURCHASED' | 'ALREADY_REVIEWED';
    orderId?: string;
  };
}

export default function ReviewsSection({ rating, reviewCount, reviews, productSlug, reviewEligibility = { eligible: false, reason: 'NOT_LOGGED_IN' } }: ReviewsSectionProps) {
  const [helpfulCounts, setHelpfulCounts] = useState<Record<string, number>>(
    reviews.reduce((acc, r) => ({ ...acc, [r.id]: r.helpfulCount || 0 }), {})
  );
  const [clickedHelpful, setClickedHelpful] = useState<Set<string>>(new Set());

  const handleWriteReviewClick = (e: React.MouseEvent) => {
    if (!reviewEligibility.eligible && reviewEligibility.reason !== 'NOT_LOGGED_IN' && reviewEligibility.reason !== 'NOT_PURCHASED') {
      e.preventDefault();
      // if (reviewEligibility.reason === 'NOT_LOGGED_IN') {
      //   toast.error("Please login 🔒", "You need to be logged in to write a review.", { duration: 6000 });
      // } else 
      // if (reviewEligibility.reason === 'NOT_PURCHASED') {
      //   toast.error("Purchase Required 🛍️", "Please purchase the item before you give a review.", { duration: 6000 });
      // } else 
      if (reviewEligibility.reason === 'ALREADY_REVIEWED') {
        toast.error("Already Reviewed 📝", "You have already submitted a review for this product.", { duration: 6000 });
      }
    }
  };

  const handleHelpfulClick = async (reviewId: string) => {
    const isCurrentlyClicked = clickedHelpful.has(reviewId);
    const action = isCurrentlyClicked ? 'decrement' : 'increment';
    const delta = isCurrentlyClicked ? -1 : 1;

    // Optimistically update UI
    setHelpfulCounts(prev => ({ ...prev, [reviewId]: Math.max(0, (prev[reviewId] || 0) + delta) }));
    setClickedHelpful(prev => {
      const next = new Set(prev);
      if (isCurrentlyClicked) next.delete(reviewId);
      else next.add(reviewId);
      return next;
    });

    // Fire API call
    const result = await markReviewHelpful(reviewId, action);
    if (!result.success) {
      // Revert if API failed
      setHelpfulCounts(prev => ({ ...prev, [reviewId]: Math.max(0, (prev[reviewId] || 0) - delta) }));
      setClickedHelpful(prev => {
        const next = new Set(prev);
        if (isCurrentlyClicked) next.add(reviewId);
        else next.delete(reviewId);
        return next;
      });
    } else if (typeof result.helpful_count === 'number') {
      setHelpfulCounts(prev => ({ ...prev, [reviewId]: result.helpful_count! }));
    }
  };

  // Calculate histogram data from actual reviews
  const histogram = [5, 4, 3, 2, 1].map((stars) => {
    const count = reviews.filter(r => Math.round(r.rating) === stars).length;
    const percentage = reviewCount > 0 ? Math.round((count / reviewCount) * 100) : 0;
    return { stars, percentage };
  });

  const renderStars = (ratingValue: number) => {
    return (
      <div className="flex gap-[2px] items-center text-primary-orange">
        {[1, 2, 3, 4, 5].map((star) => (
          star <= ratingValue ? <IconStarFilled key={star} className="w-[14px] h-[14px]" /> : <IconStarOutline key={star} className="w-[14px] h-[14px] text-[#e5e0da]" />
        ))}
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-[16px] items-start w-full relative shrink-0">
      <h2 className="font-bold leading-[24px] text-text-primary text-[18px]">
        Customer Reviews
      </h2>

      <div className="bg-surface-subtle border border-border-strong border-solid flex flex-col items-start rounded-[12px] w-full">
        <div className="flex flex-col gap-[16px] w-full p-[16px]">
          <div className="flex items-center justify-between w-full">
            <div className="flex gap-[8px] items-baseline">
              <p className="font-bold leading-[32px] text-text-primary text-[28px]">
                {rating.toFixed(1)}
              </p>
              <p className="font-normal leading-[16px] text-text-muted text-[14px]">
                out of 5
              </p>
            </div>
            <div className="flex flex-col gap-[2px] items-end">
              {renderStars(Math.round(rating))}
              <p className="font-normal leading-[16px] text-text-muted text-[12px]">
                {reviewCount} {reviewCount === 1 ? 'review' : 'reviews'}
              </p>
            </div>
          </div>

          <div className="h-px w-full bg-border-strong"></div>

          <div className="flex flex-col gap-[6px] items-start w-full">
            {histogram.map((bar) => (
              <div key={bar.stars} className="flex gap-[8px] items-center w-full">
                <p className="font-medium leading-[16px] text-text-secondary text-[12px] w-[24px]">
                  {bar.stars}★
                </p>
                <div className="bg-border-strong flex h-[6px] rounded-[3px] w-[140px] md:flex-1 overflow-hidden">
                  <div
                    className="bg-primary-orange h-full rounded-[3px]"
                    style={{ width: `${bar.percentage}%` }}
                  ></div>
                </div>
                <p className="font-normal leading-[16px] text-text-muted text-[12px] text-right w-[36px]">
                  {bar.percentage}%
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="w-full px-[16px] pb-[16px]">
          <Link 
            href={
              reviewEligibility.eligible && reviewEligibility.orderId
                ? `/product/${productSlug}/write-review?orderId=${reviewEligibility.orderId}`
                : `/product/${productSlug}/write-review`
            } 
            onClick={handleWriteReviewClick}
            className="w-full py-[10px] rounded-[999px] border border-primary-orange text-primary-orange font-semibold text-[14px] flex items-center justify-center bg-white transition-colors hover:bg-primary-orange/5 cursor-pointer"
          >
            Write a Review
          </Link>
        </div>
      </div>

      <div className="flex flex-col gap-[24px] w-full mt-4">
        {reviews.map((review) => {
          const helpfulCount = helpfulCounts[review.id] || 0;
          return (
            <div key={review.id} className="flex flex-col gap-[12px] pb-[20px] border-b border-border-strong border-solid last:border-0 last:pb-0 w-full">
              <div className="flex justify-between items-start w-full">
                {renderStars(review.rating)}
                <span className="text-[12px] text-text-muted">
                  {new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(review.createdAt))}
                </span>
              </div>

              <h3 className="text-[14px] font-bold text-text-primary">
                {review.title}
              </h3>

              <p className="text-[14px] text-text-secondary leading-[20px]">
                {review.body}
              </p>

              {review.images && review.images.length > 0 && (
                <div className="flex gap-[8px] mt-[4px]">
                  {review.images.map((imgUrl, i) => (
                    <div key={i} className="relative w-[64px] h-[64px] rounded-[8px] overflow-hidden bg-surface-neutral border border-border-strong">
                      <Image src={imgUrl} alt="Review image" fill className="object-cover" />
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-[6px] mt-[4px]">
                <span className="text-[12px] font-medium text-text-primary">
                  {review.customerName}
                </span>
                {review.isVerifiedPurchase && (
                  <div className="bg-[#fff4eb] text-primary-orange rounded-[999px] px-[6px] py-[2px] flex items-center gap-[4px]">
                    <IconCheck />
                    <span className="text-[10px] font-semibold">Verified Purchase</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between mt-[4px] w-full">
                <span className="text-[12px] text-text-muted">
                  {helpfulCount} {helpfulCount === 1 ? 'person' : 'people'} found this helpful
                </span>
                <button
                  onClick={() => handleHelpfulClick(review.id)}
                  className={`flex items-center gap-[6px] border rounded-[999px] px-[12px] py-[6px] transition-colors ${clickedHelpful.has(review.id)
                      ? 'border-primary-orange text-primary-orange bg-[#fff4eb]'
                      : 'border-border-strong text-text-secondary hover:bg-surface-subtle'
                    }`}
                >
                  {clickedHelpful.has(review.id) ? <IconThumbsUpFilled /> : <IconThumbsUp />}
                  <span className="text-[12px] font-medium">Helpful</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
