"use client";

import Link from "next/link";
import { ComponentProps } from "react";

export default function ClientLink(props: ComponentProps<typeof Link>) {
  const { onClick, ...rest } = props;
  
  // We use prefetch={true} to eagerly load the page data in the background,
  // ensuring the navigation is literally 0ms and perfectly instant!
  return (
    <Link 
      prefetch={process.env.NODE_ENV === 'production'} 
      {...rest} 
      onClick={(e) => {
        // Fire instantly for 0ms delay as requested
        if (onClick) onClick(e);
      }} 
    />
  );
}
