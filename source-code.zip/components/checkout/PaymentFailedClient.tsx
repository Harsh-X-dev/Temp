'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import BackButton from '@/components/ui/buttons/BackButton';

/**
 * PaymentFailedClient — Matches Figma node 1304-15600.
 * Displays when a transaction fails or is declined by the gateway.
 */
export default function PaymentFailedClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    router.prefetch('/checkout/payment');
  }, [router]);

  const total = searchParams.get('total')
    ? parseFloat(searchParams.get('total') as string).toLocaleString('en-IN')
    : '1,349.10';

  const reason = searchParams.get('reason') || 'Your payment could not be processed. Please try again or use a different payment method.';

  return (
    <div className="bg-[#fbf9f5] min-h-screen flex flex-col items-center justify-between w-full font-['Montserrat']">
      <div className="w-full max-w-full md:max-w-[480px] mx-auto min-h-screen flex flex-col justify-between bg-[#fbf9f5] relative md:border-x md:border-[#e5e0da] shadow-sm pb-[24px]">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-white border-b border-[#e5e0da] px-[16px] py-[12px] flex items-center justify-between w-full">
          <div className="flex items-center gap-[12px]">
            <BackButton href="/checkout/payment" />
            <h1 className="font-bold text-[16px] text-[#211e1a]">Payment</h1>
          </div>
        </header>

        {/* Main Content Card */}
        <main className="flex flex-col items-center justify-center px-[24px] py-[40px] flex-1 w-full text-center">
          {/* Exclamation Error Icon matching Figma */}
          <div className="bg-[#ff5400] relative rounded-full size-[72px] flex items-center justify-center shadow-md mb-[24px]">
            <svg
              width="36"
              height="36"
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
          </div>

          <h2 className="font-bold text-[22px] leading-[28px] text-[#211e1a] mb-[8px]">
            Payment Failed
          </h2>

          <p className="font-normal text-[13px] leading-[20px] text-[#6b6459] max-w-[320px] mb-[28px]">
            {reason}
          </p>

          {/* Order Amount Card matching Figma */}
          <div className="bg-white border border-[#e5e0da] rounded-[16px] p-[16px] px-[20px] flex items-center justify-between w-full max-w-[360px] shadow-xs mb-[32px]">
            <span className="font-normal text-[14px] text-[#6b6459]">
              Order Amount
            </span>
            <span className="font-bold text-[16px] text-[#211e1a]">
              ₹{total}
            </span>
          </div>

          {/* Action Buttons matching Figma */}
          <div className="flex flex-col gap-[12px] w-full max-w-[360px]">
            <button
              type="button"
              onClick={() => router.push('/checkout/payment')}
              className="bg-[#ff5400] hover:bg-[#e04a00] active:scale-[0.99] text-white font-semibold text-[15px] h-[50px] rounded-full w-full flex items-center justify-center transition-all cursor-pointer shadow-xs"
            >
              Try Again
            </button>

            <button
              type="button"
              onClick={() => router.push('/checkout/payment')}
              className="bg-transparent hover:bg-[#fff5ee] active:scale-[0.99] border border-[#ff5400] text-[#ff5400] font-semibold text-[15px] h-[50px] rounded-full w-full flex items-center justify-center transition-all cursor-pointer"
            >
              Change Payment Method
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
