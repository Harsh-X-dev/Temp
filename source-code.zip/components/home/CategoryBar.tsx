"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { CategoryConfig } from "@/types/shared.types";

interface CategoryBarProps {
  categories: CategoryConfig[];
}

/**
 * Horizontally scrollable category bar with circular icons.
 * Active category is derived from the current pathname so that
 * deep links and page refreshes always highlight the correct circle.
 *
 * - /               → "all" is active
 * - /collection/[slug] → that slug is active
 *
 * Scroll position is preserved naturally because this component stays
 * mounted inside app/(shop)/collection/layout.tsx while navigating
 * between categories — no storage mechanism is needed.
 */
export default function CategoryBar({ categories }: CategoryBarProps) {
  const pathname = usePathname();

  // Derive the active slug from the current route
  const activeSlug = (() => {
    const match = pathname.match(/^\/collection\/([^/]+)/);
    return match ? match[1] : "all";
  })();

  return (
    <section aria-label="Product categories" className="w-full">
      <div
        className="no-scrollbar flex items-start gap-4 overflow-x-auto scroll-smooth px-4 py-2 sm:px-5 md:px-6 lg:px-8"
        style={{ scrollSnapType: "x mandatory" }}
      >
        {categories.map((cat) => {
          const isActive = cat.id === activeSlug;
          const href =
            cat.id === "all" ? "/collection/all" : `/collection/${cat.id}`;

          return (
            <Link
              key={cat.id}
              href={href}
              aria-current={isActive ? "page" : undefined}
              className={`group flex shrink-0 flex-col items-center gap-2 focus-visible:outline-none transition-all duration-300 ease-out hover:scale-[1.03] active:scale-[0.97]`}
              style={{ scrollSnapAlign: "start" }}
            >
              {/* Outer selection  wrapper */}
              <div
                className={`flex items-center justify-center rounded-full transition-colors duration-300 ${isActive
                  ? "border-[2.5px] border-primary-orange p-[3px]"
                  : "border-[2.5px] border-transparent p-[3px]"
                  }`}
              >
                {/* Image Container */}
                <div
                  className={`flex size-[60px] items-center justify-center overflow-hidden rounded-full transition-all duration-300 md:size-[68px] ${isActive
                    ? "bg-white"
                    : "bg-surface-subtle/50  -black/5 group-hover:-black/10 group-hover:"
                    }`}
                >
                  {cat.icon ? (
                    <Image
                      src={cat.icon}
                      alt={cat.label}
                      width={68}
                      height={68}
                      className="size-full object-cover transition-transform duration-500 group-hover:scale-110"
                      sizes="(max-width: 768px) 60px, 68px"
                      quality={75}
                    />
                  ) : (
                    /* "All" fallback — gradient circle with a sparkle glyph */
                    <span
                      className="flex size-full items-center justify-center bg-gradient-to-br from-primary-orange to-[#ff8c42] text-xl text-white select-none transition-transform duration-500 group-hover:scale-110"
                      aria-hidden="true"
                    >
                      ✨
                    </span>
                  )}
                </div>
              </div>

              {/* Label */}
              <span
                className={`max-w-[76px] text-center text-[11px] leading-3 transition-colors duration-300 md:text-xs md:leading-4 ${isActive
                  ? "font-semibold text-primary-orange"
                  : "font-medium text-gray-600 group-hover:text-gray-900"
                  }`}
              >
                {cat.label}
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
