export function ReviewsSkeleton() {
  return (
    <div className="flex flex-col gap-4 animate-pulse">
      {/* Summary Skeleton */}
      <div className="flex flex-col gap-4 py-6 md:py-8 lg:flex-row lg:items-center lg:justify-between px-4 lg:px-0">
        <div className="flex items-center gap-4">
          <div className="size-[60px] rounded-full bg-surface-neutral md:size-[80px]" />
          <div className="space-y-2">
            <div className="h-5 w-40 rounded bg-surface-neutral" />
            <div className="h-4 w-32 rounded bg-surface-neutral" />
          </div>
        </div>
      </div>
      
      {/* Card Skeletons */}
      {[...Array(3)].map((_, i) => (
        <div key={i} className="rounded-xl border border-border-strong bg-white p-4 md:p-5 mx-4 lg:mx-0">
          <div className="flex justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="size-12 rounded-lg bg-surface-neutral" />
              <div className="space-y-2 py-1">
                <div className="h-4 w-32 rounded bg-surface-neutral" />
                <div className="h-3 w-24 rounded bg-surface-neutral" />
              </div>
            </div>
            <div className="h-3 w-16 rounded bg-surface-neutral" />
          </div>
          <div className="mt-4 space-y-2">
            <div className="h-4 w-24 rounded bg-surface-neutral" />
            <div className="h-4 w-48 rounded bg-surface-neutral" />
            <div className="h-3 w-full rounded bg-surface-neutral" />
            <div className="h-3 w-2/3 rounded bg-surface-neutral" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ReviewsEmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      <div className="flex size-20 items-center justify-center rounded-full bg-white -border-light mb-5">
        <svg
          className="size-10 text-text-muted"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={1.5}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
          />
        </svg>
      </div>
      <h3 className="text-lg font-bold text-text-primary">No reviews yet</h3>
      <p className="mt-1 text-sm text-text-secondary max-w-sm">
        You haven&apos;t left any reviews for your past purchases. Share your experience with the community!
      </p>
    </div>
  );
}
