import BackButton from "@/components/ui/buttons/BackButton";
import CartButton from "@/components/ui/buttons/CartButton";
import WishlistButton from "@/components/ui/buttons/WishlistButton";

export default function ReviewsPageHeader() {
  return (
    <header className="sticky top-0 z-50 flex h-[58px] lg:h-auto items-center justify-between border-b border-border-strong lg:border-none bg-white px-4 lg:px-0 lg:pt-8 lg:mb-2 lg:max-w-3xl mx-auto w-full lg:static">
      <div className="flex gap-3 lg:gap-4 items-center relative">
        <BackButton href="/profile" className="size-10 lg:size-12 shrink-0" />
        <h1 className="text-lg lg:text-3xl font-bold text-text-primary">My Reviews</h1>
      </div>
      <div className="flex items-center gap-2">
        <WishlistButton
          className="flex size-10 items-center justify-center rounded-full border border-border-strong bg-white hover:bg-surface-neutral active:scale-95 relative text-text-primary"
          iconClassName="size-5"
        />
        <CartButton
          className="flex size-10 items-center justify-center rounded-full border border-border-strong bg-white hover:bg-surface-neutral active:scale-95 relative text-text-primary"
          iconClassName="size-5"
        />
      </div>
    </header>
  );
}
