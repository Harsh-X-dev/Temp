/**
 * HTTP client.
 * Built on axios — the only place in the project that creates an axios instance.
 * All service modules must go through `api`; never create axios instances directly.
 */
import axios, { type AxiosError } from "axios";
import { config } from "@/lib/constants/config";

export const api = axios.create({
  baseURL: config.apiBaseUrl,
  headers: {
    "Content-Type": "application/json",
  },
});

// Interceptor: Normalise request URLs to prevent path duplication or missing /api/v1 prefix
api.interceptors.request.use((config) => {
  if (config.url) {
    if (config.url.startsWith("/api/v1/")) {
      config.url = config.url.replace(/^\/api\/v1\//, "/");
    } else if (config.url.startsWith("/api/v1")) {
      config.url = config.url.replace(/^\/api\/v1/, "/");
    } else if (config.url.startsWith("/v1/")) {
      config.url = config.url.replace(/^\/v1\//, "/");
    } else if (config.url.startsWith("/v1")) {
      config.url = config.url.replace(/^\/v1/, "/");
    }
  }
  return config;
});

/**
 * Typed error wrapper for API failures.
 * Normalises axios errors into a simple { status, message } shape that hooks
 * can catch without importing axios directly.
 */
export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }

  /** Build an ApiError from an unknown catch value. */
  static from(err: unknown): ApiError {
    if (axios.isAxiosError(err)) {
      const axiosErr = err as AxiosError<{ message?: string }>;
      const status = axiosErr.response?.status ?? 0;
      const message =
        axiosErr.response?.data?.message ??
        axiosErr.message ??
        `HTTP ${status}`;
      return new ApiError(status, message);
    }
    if (err instanceof ApiError) return err;
    return new ApiError(0, "Something went wrong.");
  }
}
