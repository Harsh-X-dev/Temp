/**
 * Collection service — the only module that queries the `collections` table.
 *
 * Maps DB rows to the `CategoryConfig` interface used by CategoryBar so
 * the UI layer is fully insulated from the schema.
 */
import { createSupabaseServerClient } from "@/services/supabase/server";
import type { CategoryConfig } from "@/types/shared.types";

/** Raw row shape — only the columns we SELECT. */
interface CollectionRow {
  id: string; // uuid — kept internally, not exposed to UI
  title: string;
  slug: string;
  image_url: string | null;
  sort_order: number;
}

/**
 * The virtual "All" entry is never stored in the database.
 * It is always prepended to the list in application code.
 */
const ALL_CATEGORY: CategoryConfig = {
  id: "all",
  label: "All",
  icon: "", // CategoryBar renders a gradient fallback when icon is empty
};

/**
 * Fetch all active collections ordered by sort_order.
 * Prepends the virtual "All" entry.
 *
 * Returns [ALL_CATEGORY] on error so the category bar stays visible.
 */
export async function getActiveCollections(): Promise<CategoryConfig[]> {
  const supabase = createSupabaseServerClient();

  const { data, error } = await supabase
    .from("collections")
    .select("id, title, slug, image_url, sort_order")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })
    .returns<CollectionRow[]>();

  if (error) {
    console.error("[CollectionService] Failed to fetch collections:", error.message);
    return [ALL_CATEGORY];
  }

  if (!data || data.length === 0) {
    return [ALL_CATEGORY];
  }

  const categories: CategoryConfig[] = data.map((row) => ({
    id: row.slug,
    label: row.title,
    icon: row.image_url ?? "",
  }));

  return [ALL_CATEGORY, ...categories];
}

/**
 * Fetch a single collection by its URL slug.
 * Returns `undefined` for unknown or inactive slugs — callers should
 * invoke `notFound()` in that case.
 */
export async function getCollectionBySlug(
  slug: string,
): Promise<CategoryConfig | undefined> {
  if (slug === "all") {
    return ALL_CATEGORY;
  }

  const supabase = createSupabaseServerClient();

  const { data, error } = await supabase
    .from("collections")
    .select("id, title, slug, image_url")
    .eq("slug", slug)
    .eq("is_active", true)
    .maybeSingle();

  if (error) {
    console.error("[CollectionService] Failed to fetch collection by slug:", error.message);
    return undefined;
  }

  if (!data) return undefined;

  return {
    id: data.slug,
    label: data.title,
    icon: data.image_url ?? "",
  };
}

/**
 * Fetch the internal UUID for a collection slug.
 * Used by the product service to filter products by collection.
 * Returns `null` for unknown or inactive slugs.
 */
export async function getCollectionIdBySlug(slug: string): Promise<string | null> {
  const supabase = createSupabaseServerClient();

  const { data, error } = await supabase
    .from("collections")
    .select("id")
    .eq("slug", slug)
    .eq("is_active", true)
    .maybeSingle();

  if (error || !data) return null;
  return data.id;
}
